package ej5;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Ejercicio5
 */
public class Ejercicio5 extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Ejercicio5() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
		String asignaturas = request.getParameter("asignaturas");
        String[] actividadesArray = request.getParameterValues("actividades");
        String sexo = request.getParameter("sexo");
        
        out.println("<html>");
        out.println("<body>");
        out.println("<h2>Recogida de datos</h2>");
        out.println("<p>Asignaturas: " + asignaturas + "</p>");
        
        out.println("<p>Sexo: " + sexo + "</p>");
        
        out.println("<p>Actividades :</p>");
        if (actividadesArray != null) {
            for (String actividades : actividadesArray) {
                out.println("<p>" + actividades + "</p>");
            }
        }
        
        out.println("</body>");
        out.println("</html>");
	}

}
