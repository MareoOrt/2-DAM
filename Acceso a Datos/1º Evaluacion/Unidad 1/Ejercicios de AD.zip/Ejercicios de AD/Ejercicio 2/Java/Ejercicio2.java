package ej2;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Ejercicio2
 */
public class Ejercicio2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Ejercicio2() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html;charset=UTF-8");

        String[] nombres = request.getParameterValues("nombre");
        String[] apellidos = request.getParameterValues("apellidos");
        String[] edades = request.getParameterValues("edad");

//        if (nombres == null || apellidos == null || edades == null) {
//            response.getWriter().println("Error: Los datos proporcionados no son válidos.");
//           return;
//        }

        ArrayList<Persona> personas = new ArrayList<>();
        for (int i = 0; i < nombres.length; i++) {
            String nombre = nombres[i];
            String apellido = apellidos[i];
            int edad = Integer.parseInt(edades[i]);
            String contacto = contactos[i];
            personas.add(new Persona(nombre, apellido, edad, contacto));
        }

        response.getWriter().println("<html>");
        response.getWriter().println("<head><title>Lista de Personas</title></head>");
        response.getWriter().println("<body>");
        response.getWriter().println("<h1>Lista de Personas</h1>");
        response.getWriter().println("<table border='1'>");
        response.getWriter().println("<tr><th>Nombre</th><th>Apellidos</th><th>Edad</th><th>Contacto</th></tr>");

        for (Persona persona : personas) {
            response.getWriter().println("<tr>");
            response.getWriter().println("<td>" + persona.getNombre() + "</td>");
            response.getWriter().println("<td>" + persona.getApellidos() + "</td>");
            response.getWriter().println("<td>" + persona.getEdad() + "</td>");
            response.getWriter().println("</tr>");
        }

        response.getWriter().println("</table>");
        response.getWriter().println("</body>");
        response.getWriter().println("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
