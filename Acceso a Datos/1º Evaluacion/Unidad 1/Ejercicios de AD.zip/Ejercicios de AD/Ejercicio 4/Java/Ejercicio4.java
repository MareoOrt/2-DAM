package ej4;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Ejercicio4
 */
public class Ejercicio4 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor.
	 */
	public Ejercicio4() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		response.setContentType("text/html;charset=UTF-8");

		ArrayList<String> nombresParametros = request.getParameterNames();

		response.getWriter().println("<html>");
		response.getWriter().println("<head><title>Datos Recibidos</title></head>");
		response.getWriter().println("<body>");
		response.getWriter().println("<h2>Datos Recibidos</h2>");

		for (String nombreParametro : nombresParametros) {
			String[] valoresParametro = request.getParameterValues(nombreParametro);

			response.getWriter().println("<p>" + nombreParametro + ": ");

			if (valoresParametro != null) {
				for (String valor : valoresParametro) {
					response.getWriter().println(valor + " ");
				}
			}

			response.getWriter().println("</p>");
		}

		response.getWriter().println("</body>");
		response.getWriter().println("</html>");
	}
}
