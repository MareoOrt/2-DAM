package ej3;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Ejercicio3
 */
public class Ejercicio3 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor.
	 */
	public Ejercicio3() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
		response.setContentType("text/html;charset=UTF-8");

		String nombre = request.getParameter("nombre");
		String apellidos = request.getParameter("apellidos");
		String direccion = request.getParameter("direccion");
		String[] tarjetas = request.getParameterValues("tarjetas");
		String nTarjeta = request.getParameter("nTarjeta");

		response.getWriter().println("<html>");
		response.getWriter().println("<head><title>Datos Recibidos</title></head>");
		response.getWriter().println("<body>");
		response.getWriter().println("<h2>Datos Recibidos</h2>");
		response.getWriter().println("<p>Nombre: " + nombre + "</p>");
		response.getWriter().println("<p>Apellidos: " + apellidos + "</p>");
		response.getWriter().println("<p>Dirección: " + direccion + "</p>");

		response.getWriter().println("<p>Tipo de tarjeta:</p>");
		if (tarjetas != null) {
			for (String tarjeta : tarjetas) {
				response.getWriter().println("<p>" + tarjeta + "</p>");
			}
		}

		response.getWriter().println("<p>Número de tarjeta de crédito: " + nTarjeta + "</p>");
		response.getWriter().println("</body>");
		response.getWriter().println("</html>");
	}

}
