
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Ejercicio1B
 */
public class Ejercicio1B extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor.
	 */
	public Ejercicio1B() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html;charset=UTF-8");

		response.getWriter().println("<form action=\"SaludoIdiomaServlet\" method=\"post\">");
		response.getWriter()
				.println("<input type=\"radio\" name=\"idiomaSeleccionado\" value=\"ingles\">Inglés (Hello World)<br>");
		response.getWriter().println("<input type=\"radio\" name=\"idiomaSeleccionado\" value=\"espanol\">Español<br>");
		response.getWriter().println(
				"<input type=\"radio\" name=\"idiomaSeleccionado\" value=\"italiano\">Italiano (Ciao a tutti)<br>");
		response.getWriter().println(
				"<input type=\"radio\" name=\"idiomaSeleccionado\" value=\"frances\">Francés (Bonjour Tout)<br>");
		response.getWriter().println("<input type=\"submit\" value=\"Saludar\">");
		response.getWriter().println("</form>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		response.setContentType("text/html;charset=UTF-8");
		String idiomaSeleccionado = request.getParameter("idiomaSeleccionado");

		String mensaje = obtenerMensajeSaludo(idiomaSeleccionado);
		response.getWriter().println("Saludo en " + idiomaSeleccionado + ": " + mensaje);
	}
    private String obtenerMensajeSaludo(String idioma) {
        switch (idioma) {
        case "ingles":
            return "Hello World";
        case "espanol":
            return "Hola mundo";
        case "italiano":
            return "Ciao a tutti";
        case "frances":
            return "Bonjour Tout";
        default:
            return "El idioma no está en nuestra base de datos";
    }
    }

}
