

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Ejercicio1C
 */
public class Ejercicio1C extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Ejercicio1C() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html;charset=UTF-8");

        response.getWriter().println("<form action=\"SaludoPersonalizadoServlet\" method=\"post\">");
        response.getWriter().println("Mensaje <input type=\"text\" name=\"mensaje\"><br>");
        response.getWriter().println("Firma <input type=\"text\" name=\"firma\"><br>");
        response.getWriter().println("<input type=\"submit\" value=\"Enviar\">");
        response.getWriter().println("<input type=\"reset\" value=\"Borrar\">");
        response.getWriter().println("</form>");
        
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
        response.setContentType("text/html;charset=UTF-8");
        String mensaje = request.getParameter("mensaje");
        String firma = request.getParameter("firma");

        response.getWriter().println("Mensaje personalizado: " + mensaje + "<br>");
        response.getWriter().println("Firma: " + firma);
	}

}
