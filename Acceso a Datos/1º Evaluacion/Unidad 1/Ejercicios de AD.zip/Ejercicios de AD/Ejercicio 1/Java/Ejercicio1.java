

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Ejercicio1
 */
public class Ejercicio1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public Ejercicio1() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
        String idioma = request.getParameter("idioma");

        if (idioma == null) {
            response.getWriter().println("<form action=\"SaludoServlet\" method=\"get\">");
            response.getWriter().println("<input type=\"submit\" value=\"Salúdame\">");
            response.getWriter().println("</form>");
        } else {
            String mensaje = obtenerMensajeSaludo(idioma);
            response.getWriter().println(mensaje);
        }	
        
	}
	private String obtenerMensajeSaludo(String idioma) {
        switch (idioma) {
            case "ingles":
                return "Hello World";
            case "espanol":
                return "Hola mundo";
            case "italiano":
                return "Ciao a tutti";
            case "frances":
                return "Bonjour Tout";
            default:
                return "El idioma no está en nuestra base de datos";
        }
    }
}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
