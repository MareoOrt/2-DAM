package com.example.ejer01_calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ArrayList<Button> listaBotones = new ArrayList<>();
    int primerDigito = Integer.MIN_VALUE;
    int segundoDigito = Integer.MIN_VALUE;
    int resultado = Integer.MIN_VALUE;
    boolean operadorBoolean = false;
    char operadorSeleccionado = ' ';
    String cadenaMostrar = " ";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ((Button) findViewById(R.id.b_sumar)).setOnClickListener(this);
        ((Button) findViewById(R.id.b_restar)).setOnClickListener(this);
        ((Button) findViewById(R.id.b_ac)).setOnClickListener(this);
        ((Button) findViewById(R.id.b_igual)).setOnClickListener(this);

        for (int i = 0; i < 10; i++) {
            listaBotones.add((Button) findViewById(
                    getResources().getIdentifier("b_" + i, "id", getPackageName())
            ));
        }
        for (Button boton : listaBotones) {
            boton.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.b_sumar) {
            seleccionarOperador((Button) v);
        } else if (v.getId() == R.id.b_restar) {
            seleccionarOperador((Button) v);
        } else if (v.getId() == R.id.b_ac) {
            resetear();
        } else if (v.getId() == R.id.b_igual) {
            calcularResultado();
            prepararSiguienteCalculo();
        } else {
            seleccionarDigitos((Button) v);
        }

        Log.d("depurando",String.valueOf(operadorSeleccionado));
        Log.d("depurando",String.valueOf(operadorBoolean));
        Log.d("depurando",String.valueOf(primerDigito));
        Log.d("depurando",String.valueOf(segundoDigito));
        ((TextView) findViewById(R.id.tv_solucion)).setText(cadenaMostrar);
    }
    private void seleccionarOperador(Button b) {
        if (!operadorBoolean) {
            operadorBoolean = true;
            cadenaMostrar = cadenaMostrar + " " + operadorSeleccionado;
        }

        if (segundoDigito != Integer.MIN_VALUE) {
            calcularResultado();
            prepararSiguienteCalculo();
            seleccionarOperador(b);
        } else {
            Log.d("depurando", "AAAAA" + cadenaMostrar);
            operadorSeleccionado = b.getText().toString().charAt(0);
            cadenaMostrar = cadenaMostrar.substring(0, cadenaMostrar.length() - 2) + " " + operadorSeleccionado;
        }
    }

    private void seleccionarDigitos(Button b) {
        if (!operadorBoolean) {
            primerDigito = primerDigito * 10 + Integer.parseInt(b.getText().toString());
            cadenaMostrar = String.valueOf(primerDigito);
        } else {
            segundoDigito = segundoDigito * 10 + Integer.parseInt(b.getText().toString());
            if (String.valueOf(segundoDigito).length() == 1) {
                cadenaMostrar = cadenaMostrar + " " + segundoDigito;
            } else {
                cadenaMostrar = cadenaMostrar.substring(0, cadenaMostrar.length() - String.valueOf(segundoDigito).length()) + " " + segundoDigito;
            }
            //calcularResultado();
            //prepararSiguienteCalculo();
        }

    }

    private void calcularResultado() {
        switch (operadorSeleccionado) {
            case '+':
                resultado = primerDigito + segundoDigito;
                break;
            case '-':
                resultado = primerDigito - segundoDigito;
                break;
        }
    }

    private void resetear() {
        primerDigito = 0;
        resultado = Integer.MIN_VALUE;
        segundoDigito = Integer.MIN_VALUE;
        operadorBoolean = false;
        operadorSeleccionado = ' ';
        cadenaMostrar = "0";
        cadenaMostrar = String.valueOf(primerDigito);
    }

    private void prepararSiguienteCalculo() {
        primerDigito = resultado;
        resultado = Integer.MIN_VALUE;
        segundoDigito = Integer.MIN_VALUE;
        operadorBoolean = false;
        operadorSeleccionado = ' ';
        cadenaMostrar = String.valueOf(primerDigito);
    }
}