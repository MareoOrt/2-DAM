package com.example.ejerciciocomponentesbasicos;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    ArrayList<HashMap<String, String>> datosDesplegableDoble;
    ArrayList<String> datosDeplegable;
    HashMap<String, String> itemDeplegableDoble;
    ArrayAdapter<String> adaptadorDatosDesplegable;
    SimpleAdapter adaptadorDatosDesplegable2;
    Spinner desplegableDatos2;
    Spinner desplegableDatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inicializarSpinnerComunidad();
        inicializarRadioButton();
        inicializarSwitch();
        inicializarDesplegable();
        inicializarDesplegableDoble();
        guardarDatosUsuario();
        /*Añadir al desplegable doble nuevos datos, Al pulsar cualquiera de los dos deplegables muestra en consola los datos del objeto usuario
         * que esta en esa posicion*/
    }

    private void inicializarDesplegable() {
        desplegableDatos = (Spinner) findViewById(R.id.s_datosUsuarios);
        datosDeplegable = new ArrayList<>();
        adaptadorDatosDesplegable = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, datosDeplegable);
        desplegableDatos.setAdapter(adaptadorDatosDesplegable);
    }

    private void inicializarDesplegableDoble() {
        desplegableDatos2 = (Spinner) findViewById(R.id.s_datosUsuarios2);
        datosDesplegableDoble = new ArrayList<HashMap<String, String>>();
        itemDeplegableDoble = new HashMap<String, String>();
        itemDeplegableDoble.put("Nombre", "Juan");
        itemDeplegableDoble.put("Profesion", "Informatico");
        datosDesplegableDoble.add(itemDeplegableDoble);
        adaptadorDatosDesplegable2 = new SimpleAdapter(
                this,
                datosDesplegableDoble,
                android.R.layout.simple_list_item_2,
                new String[]{"Nombre", "Profesion"},
                new int[]{android.R.id.text1, android.R.id.text2});
        desplegableDatos2.setAdapter(adaptadorDatosDesplegable2);

        desplegableDatos2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                HashMap<String, String> usuario = datosDesplegableDoble.get(position);
                Toast.makeText(getApplicationContext(), "Nombre: " + usuario.get("Nombre") +
                        "\nProfesión:" + usuario.get("Profesion"), Toast.LENGTH_SHORT).show();
                Log.d("USUARIO SELECCIONADO","Nombre: " + usuario.get("Nombre") +
                        ", Profesión:" + usuario.get("Profesion"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void guardarDatosUsuario() {
        ((Button) findViewById(R.id.b_recuperarTexto)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Usuario usuario = new Usuario();
                usuario.setNombre(((TextView) findViewById(R.id.et_nombre)).getText().toString());
                usuario.setComunidadAutonoma(((Spinner) findViewById(R.id.s_comunidadAutonoma)).getSelectedItem().toString());
                usuario.setCiudadNacimiento(((Spinner) findViewById(R.id.s_ciudadDeNacimiento)).getSelectedItem().toString());
                RadioButton rb_selecionado = findViewById((((RadioGroup) findViewById(R.id.rg_profesion)).getCheckedRadioButtonId()));
                usuario.setProfesion(rb_selecionado.getText().toString());
                usuario.setCasado(((Switch) findViewById(R.id.s_soltero)).isChecked());
                ArrayList<String> deportes = new ArrayList<>();
                if (((CheckBox) findViewById(R.id.cb_baloncesto)).isChecked()) {
                    deportes.add("Baloncesto");
                }
                if (((CheckBox) findViewById(R.id.cb_futbol)).isChecked()) {
                    deportes.add("Futbol");
                }
                if (((CheckBox) findViewById(R.id.cb_pingpong)).isChecked()) {
                    deportes.add("PingPong");
                }
                usuario.setDeportes(deportes);
                //Log.d("DEPURANDO", usuario.toString());

                desplegableDatos = ((Spinner) findViewById(R.id.s_datosUsuarios));
                ((ArrayAdapter<String>) desplegableDatos.getAdapter()).add(usuario.toString());
                HashMap<String, String> itemNuevo = new HashMap<String, String>();
                itemNuevo.put("Nombre", usuario.getNombre());
                itemNuevo.put("Profesion", usuario.getProfesion());
                datosDesplegableDoble.add(itemNuevo);
                desplegableDatos.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        Toast.makeText(getApplicationContext(),
                                desplegableDatos.getItemAtPosition(position).toString(),
                                Toast.LENGTH_SHORT).show();
                        Log.d("USUARIO SELECCIONADO",desplegableDatos.getItemAtPosition(position).toString());
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

            }
        });
    }

    private void inicializarSwitch() {
        ((Switch) findViewById(R.id.s_soltero)).setOnCheckedChangeListener((compoundButton, casado) -> {
            //Log.d("Depurando", "Activado: " + casado);

            if (casado) {
                Toast.makeText(getApplicationContext(), "Casado", Toast.LENGTH_SHORT).show();
            } else {
                Snackbar.make(compoundButton, "Soltero", Snackbar.LENGTH_SHORT).show();
            }
        });
    }

    private void inicializarRadioButton() {
        ((RadioGroup) findViewById(R.id.rg_profesion)).setOnCheckedChangeListener((radioGroup, i) ->
                Log.d("Depurando", ((TextView) findViewById(i)).getText().toString()));
    }

    private void inicializarSpinnerComunidad() {
        ArrayList<String> datos = new ArrayList<>();
        datos.add("Valladolid");
        datos.add("Zamora");
        datos.add("Soria");
        datos.add("Salamanca");
        datos.add("Segovia");
        datos.add("Avila");
        datos.add("Palencia");
        datos.add("Burgos");
        Spinner despleglable_comunidadAuto = (Spinner) findViewById(R.id.s_comunidadAutonoma);
        ArrayAdapter<String> adaptadorComunidad = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_1, datos);
        despleglable_comunidadAuto.setAdapter(adaptadorComunidad);
        datos.add("León");

        despleglable_comunidadAuto.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //Log.d("Depurando", ((TextView) view).getText().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
}
