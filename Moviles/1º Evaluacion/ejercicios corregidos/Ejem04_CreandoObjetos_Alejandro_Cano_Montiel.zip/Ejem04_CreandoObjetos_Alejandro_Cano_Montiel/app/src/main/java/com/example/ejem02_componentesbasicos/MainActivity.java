package com.example.ejem02_componentesbasicos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private ArrayList<HashMap<String, String>> datos2 = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inicializarSpinnerComunidad();
        inicializarSpinnerCiudadNacimiento();
        inicializarRadioButton();
        inicializarSwitch();
        inicializarDesplegable();
        inicializarDesplegableDoble();

        guardarDatosUsuario();

    }

    private void inicializarSpinnerComunidad() {
        //String[] datos={"Valladolid","Zamora","Soria","Salamanca","Segovia","Avila","Palencia","Burgos"};
        ArrayList<String> datos = new ArrayList<>();
        datos.add("Valladolid");
        datos.add("Zamora");
        datos.add("Soria");
        datos.add("Salamanca");
        datos.add("Segovia");
        Spinner despelgable_ComunidadAutonoma = ((Spinner) findViewById(R.id.s_comunidadAutonoma));
        ArrayAdapter<String> adaptador_Comunidad = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, datos);
        despelgable_ComunidadAutonoma.setAdapter(adaptador_Comunidad);
        datos.add("Avila"); //Aqui agregamos otro dato y el spinner se actualiza.

        despelgable_ComunidadAutonoma.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Log.d("depurando", ((TextView) view).getText().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    private void inicializarSpinnerCiudadNacimiento() {

        ArrayList<String> datos = new ArrayList<>();
        datos.add("Valladolid");
        datos.add("Zamora");
        datos.add("Soria");
        datos.add("Salamanca");
        datos.add("Segovia");
        Spinner despelgable_CiudadNacimiento = ((Spinner) findViewById(R.id.s_ciudadNacimiento));
        ArrayAdapter<String> adaptador_CiudadNacimiento = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, datos);
        despelgable_CiudadNacimiento.setAdapter(adaptador_CiudadNacimiento);
        datos.add("Avila"); //Aqui agregamos otro dato y el spinner se actualiza.

        despelgable_CiudadNacimiento.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Log.d("depurando", ((TextView) view).getText().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }



    private void inicializarRadioButton() {
        /*((RadioGroup)findViewById(R.id.rg_profesion)).setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                Log.d("depurando",((TextView) findViewById(i)).getText().toString());
            }
        });*/
        ((RadioGroup) findViewById(R.id.rg_profesion)).setOnCheckedChangeListener((radioGroup, i) ->
                Log.d("depurando", ((TextView) findViewById(i)).getText().toString()));
    }

    ;

    private void inicializarSwitch() {
        ((Switch) findViewById(R.id.s_casado)).setOnCheckedChangeListener((compoundButton, casado) -> {
            Log.d("depurando", " " + casado);
            if (casado)
                Toast.makeText(getApplicationContext(), "Casado", Toast.LENGTH_SHORT).show();
            else
                Snackbar.make(compoundButton, "Soltero", Snackbar.LENGTH_SHORT).show();
        });
    }

    ;

    private void inicializarDesplegable() {
        Spinner desplegableDatos = ((Spinner) findViewById(R.id.s_datosUsuarios));
        //String datos[] = {""};
        ArrayList<String>datos=new ArrayList<>();
        ArrayAdapter<String> adaptadorDatos = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, datos);
        desplegableDatos.setAdapter(adaptadorDatos);
    }

    private void inicializarDesplegableDoble() {
        Spinner desplegableDatos2 = ((Spinner) findViewById(R.id.s_datosUsuarios2));

        SimpleAdapter adaptadorDatos = new SimpleAdapter(
                this,
                datos2,
                android.R.layout.simple_list_item_2,
                new String[]{"Nombre", "Profesión"},
                new int[]{android.R.id.text1, android.R.id.text2});

        desplegableDatos2.setAdapter(adaptadorDatos);

        desplegableDatos2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                // Mostrar los datos del usuario en la consola
                Log.d("UsuarioSeleccionado", datos2.get(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // Manejo cuando no se ha seleccionado nada
            }
        });
    }



    private void guardarDatosUsuario() {
        ((Button) findViewById(R.id.b_recuperarTexto)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Usuario usuario = new Usuario();
                usuario.setNombre(((TextView) findViewById(R.id.et_nombre)).getText().toString());
                usuario.setComunidadAutonoma(((Spinner) findViewById(R.id.s_comunidadAutonoma)).getSelectedItem().toString());
                usuario.setCiudadNacimiento(((Spinner) findViewById(R.id.s_ciudadNacimiento)).getSelectedItem().toString());
                RadioButton rb_seleccionado = findViewById((((RadioGroup) findViewById(R.id.rg_profesion)).getCheckedRadioButtonId()));
                usuario.setProfesion(rb_seleccionado.getText().toString());
                usuario.setCasado(((Switch) findViewById(R.id.s_casado)).isChecked());
                ArrayList<String> deportes = new ArrayList<>();
                if (((CheckBox) findViewById(R.id.cb_baloncesto)).isChecked()) {
                    deportes.add("Baloncesto");
                }
                if (((CheckBox) findViewById(R.id.cb_futbol)).isChecked()) {
                    deportes.add("Futbol");
                }
                if (((CheckBox) findViewById(R.id.cb_pingpon)).isChecked()) {
                    deportes.add("PingPong");
                }
                usuario.setDeportes(deportes);


                Spinner desplegableDatos = ((Spinner) findViewById(R.id.s_datosUsuarios));
                ((ArrayAdapter<String>) desplegableDatos.getAdapter()).add(usuario.toString());

                // Añadir al desplegable doble nuevos datos
                HashMap<String, String> item = new HashMap<>();
                item.put("Nombre", usuario.getNombre());
                item.put("Profesión", usuario.getProfesion());
                datos2.add(item);

            // Notificar al adaptador que los datos han cambiado
                Spinner desplegableDatos2 = ((Spinner) findViewById(R.id.s_datosUsuarios2));
                ((SimpleAdapter) desplegableDatos2.getAdapter()).notifyDataSetChanged();



            }
        });
    };
}